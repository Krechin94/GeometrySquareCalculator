﻿namespace GeometryLibrary.Exceptions
{
    internal class NegativeValueException : Exception
    {
        public NegativeValueException(string message) : base(message)
        {

        }
    }
}
