using GeometryLibrary.Figures;

namespace GeometryTest
{
    [TestClass]
    public class GeometryTest
    {
        [TestMethod]
        public void TestTriangleSquare()
        {
            var triangle = new Triangle(3,4,5);
            Assert.AreEqual(6,triangle.CalculatingSquare());
        }
        [TestMethod]
        public void TestCircleSquare() 
        {
            var circle = new Circle(12);
            Assert.AreEqual (452.3893421169302, circle.CalculatingSquare());
        }
    }
}