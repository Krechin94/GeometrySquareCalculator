﻿using GeometryLibrary;
namespace TestTask
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What kind of figure\n 1 - Circle\n 2 - Triangle");
            int typeOfFigure = int.Parse(Console.ReadLine()!);
            if (typeOfFigure == 1) 
            {
                Console.WriteLine("Type your radius");
                double radius = int.Parse(Console.ReadLine()!);
                double square = Circle.CalculateSquare(radius);
                Console.WriteLine($"Square of your circle = {square}");
            }
            else
            {
                Console.WriteLine("Type length of your sides");
                Console.WriteLine("side1");
                double side1 = double.Parse(Console.ReadLine()!);
                Console.WriteLine("side2");
                double side2 = double.Parse(Console.ReadLine()!);
                Console.WriteLine("side3");
                double side3 = double.Parse(Console.ReadLine()!);

                Triangle triangle = new Triangle(side1, side2, side3);

                double square = Triangle.CalculatingSquare(triangle);
                string typeOfTriangle = Triangle.CheckingOnRectangularTriangle(triangle, square);
                Console.WriteLine($"Square of triangle = {square}, your triangle is {typeOfTriangle}");
            }
        }
    }
}
