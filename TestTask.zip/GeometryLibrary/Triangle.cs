﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeometryLibrary
{
    public class Triangle
    {
        public double side1;
        public double side2;
        public double side3;
        
        public Triangle(double side1, double side2, double side3)
        {
            this.side1 = side1;
            this.side2 = side2;
            this.side3 = side3;
        }

        public static double CalculatingSquare(Triangle triangle)
        {
            double halfPerimetr = (triangle.side1 + triangle.side2 + triangle.side3) / 2;
            double square = Math.Sqrt(halfPerimetr*(halfPerimetr-triangle.side1)*(halfPerimetr-triangle.side2)*(halfPerimetr-triangle.side3));
            return (square);
        }

        public static string CheckingOnRectangularTriangle(Triangle triangle, double square)
        {
            List<double> list = new List<double>() {triangle.side1, triangle.side2, triangle.side3 };
            list.Sort();
            double squareToCheck = (list[1] * list[0])/2;
            if (squareToCheck == square)
                return "Rectangular";
            else 
                return "nonRectangular";
        }
    }
}
