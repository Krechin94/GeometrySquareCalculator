﻿namespace GeometryLibrary
{
    public class Circle
    {
        public double radius;
        private static double pi { get; } = 3.14;
        public Circle(double radius)
        {
            this.radius = radius;
        }
        
        public static double CalculateSquare(double radius)
        {
            double square = radius * radius * pi;
            return square;
        }
        
    }
}
